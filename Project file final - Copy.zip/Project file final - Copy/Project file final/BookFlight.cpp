#include "BookFlight.h"

/*BookFlight::BookFlight(string name, int seat, double luggage, int flightNum, string destination)
{
this->name = name;
this->seat = seat;
this->luggage = luggage;
this->flightNum = flightNum;
this->destination = destination;
}*/

ostream & operator<<(ostream &out, BookFlight &b) {
	out << "Total luggage weight: " << b.luggage << " Flight Number: " << b.flightNum << endl;
	return out;
}

void BookFlight::getMenu()
{
	ifstream inFile;
	int flight[25];
	string yyz[25], dest[25], date[25], time[25];
	string iata[25];
	string city[25];

	string name;
	Date flightDate;
	int day, month, year;

	do {

		cout << "1. View Flght Schedule" << endl;
		cout << "2. Book a flight" << endl;
		cout << "3. Cancel a flight" << endl;
		cout << "4. View Boarding Pass" << endl;
		cout << "5. View Travel Destinations" << endl;
		cout << "6. Exit" << endl << endl;
		cout << "Please choose an option from above: ";
		cin >> choice;
		cout << endl;

		switch (choice) {
			//=====================================================
		case 1:

			inFile.open("FlightInfo.txt");
			if (!inFile) {
				cout << " file doesnt exist";

			}
			else {

				cout << "Flight Number" << setw(15) << "Leaving" << setw(15) << "Arriving" << setw(13) << "Date" << setw(15) << "Time" << endl;
				cout << "========================================================================" << endl;
				for (int i = 0; i < 25; i++) {
					inFile >> flight[i] >> yyz[i] >> dest[i] >> date[i] >> time[i];
					cout << setw(7) << flight[i] << setw(19) << yyz[i] << setw(14) << dest[i] << setw(19) << date[i] << setw(13) << time[i] << endl;
				}
				cout << endl;
			}
			inFile.close();
			break;
			//======================================================
		case 2:
			BookFlight::setLName(lname);
			BookFlight::setFName(fname);

			cout << "Please enter Flight Month: ";
			cin >> month;
			cout << "Please enter Flight Day: ";
			cin >> day;
			cout << "Please enter Flight Year: ";
			cin >> year;

			flightDate.setDate(month, day, year);

			BookFlight::setFlightNum(flightNum);
			BookFlight::setLuggage(luggage);
			BookFlight::setOrigin(origin);
			BookFlight::setDestination(destination);
			cout << endl;

			break;
			//======================================================
		case 3:
			BookFlight::setLName(lname);
			BookFlight::setFName(fname);
			BookFlight::setFlightNum(flightNum);

			cout << "Your Flight has been cancelled..." << endl << endl;

			break;
			//======================================================
		case 4:
			cout << "BOARDING PASS" << endl;
			cout << "--------------------------------" << endl;
			cout << "Name: " << BookFlight::getFName() << " " << BookFlight::getLName() << endl;
			flightDate.getDate();
			cout << "Flight Number: " << BookFlight::getFlightNum() << endl;
			cout << "Luggage Weight: " << BookFlight::getLuggage() << " lbs" << endl;
			cout << "Travelling From: " << BookFlight::getOrigin() << endl;
			cout << "Travelling To: " << BookFlight::getDestination() << endl;
			cout << "--------------------------------" << endl << endl;

			break;
			//======================================================
		case 5:

			inFile.open("TravelExplorer.txt");
			cout << fixed;
			cout << setw(14) << "IATA Code" << setw(25) << "Destination" << endl;
			cout << "============================================" << endl;
			for (int i = 0; i < 25; i++) {
				inFile >> iata[i];
				getline(inFile, city[i], '/');

				cout << fixed;
				cout << setw(10) << iata[i] << setw(30) << fixed << city[i] << endl;
			}
			cout << endl;
			inFile.close();
			break;
			//======================================================
		default:
			break;
		}

	} while (choice != 6);
}
