#ifndef DATE_H
#define DATE_H

#include <iostream>
class Date
{
protected:
	int day, year;
	int month;
public:
	void setDate(int, int, int);
	void getDate();
	Date();
	~Date();
};
#endif
