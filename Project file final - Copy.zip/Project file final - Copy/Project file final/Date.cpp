#include "Date.h"
#include <iostream>
#include "string"

using  namespace std;

Date::Date() {}
void Date::setDate(int d, int m, int y) {
	day = d; month = m, year = y;
}
void Date::getDate() {
	cout << "Flight Date: " << day << "/" << month << "/" << year << endl;
}
Date::~Date() {}
