#ifndef BOOKFLIGHT_h
#define BOOKFLIGHT_h

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "Date.h"

using namespace std;

class BookFlight
{
private:
	int choice;
	string fname;
	string lname;
	int seat;
	double luggage;
	int flightNum;
	string origin;
	string destination;

public:
	friend ostream & operator <<(ostream&, BookFlight&); //Overloaded << operator

	BookFlight() { choice = 0; fname = ""; lname = ""; seat = 0; luggage = 0; flightNum = 0; destination = ""; }
	~BookFlight() {}
	//BookFlight(string, int, double, int, string);

	void setChoice(int c) { choice = c; }
	int getChoice() { return choice; }

	//menu function
	void getMenu();

	//===================================================

	//Mutator
	void setFName(string n) {
		fname = n;
		cout << "Enter Last Name: ";
		cin >> fname;
	}
	void setLName(string n) {
		lname = n;
		cout << "Enter First Name: ";
		cin >> lname;
	}
	void setSeat(int s) { seat = s; }

	void setLuggage(double l) {
		luggage = l;
		cout << "How much weight will you be carrying(lbs): ";
		cin >> luggage;
	}
	void setFlightNum(int f) {
		flightNum = f;
		cout << "Enter Flight Number: ";
		cin >> flightNum;
	}
	void setOrigin(string o) {
		origin = o;
		cout << "Please Enter What Airport You are Leaving from (IATA CODE): ";
		cin >> origin;
	}
	void setDestination(string d) {
		destination = d;
		cout << "Please enter Destination (IATA CODE): ";
		cin >> destination;
	}
	//Accessor
	string getFName() {
		return fname;
	}
	string getLName() {
		return lname;
	}
	int getSeat() {
		return seat;
	}
	double getLuggage() {
		return luggage;
	}
	int getFlightNum() {
		return flightNum;
	}
	string getOrigin() {
		return origin;
	}
	string getDestination() {
		return destination;
	}
};

#endif

