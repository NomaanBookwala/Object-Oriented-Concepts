#include "BookFlight.h"

int main() {
	BookFlight obj;
	cout << "WELCOME TO THE FLIGHT RESERVATION SYSTEM" << endl;
	
	obj.getMenu();


	cin.get();
	return 0;
}

